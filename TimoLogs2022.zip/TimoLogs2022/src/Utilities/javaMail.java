/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;


/**
 *
 * @author rockr
 */
public class javaMail {
    public static void main(String[] args) throws Exception {
         EmailSending.sendMail("rockrazith9@gmail.com");
    }
    
}
